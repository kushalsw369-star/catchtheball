# 🎮 Catch the Ball Game

A simple HTML + JavaScript game made by ChatGPT.

## How to Play
- Move the basket left or right to catch the falling ball.
- Works with keyboard and touch controls.

## How to Host on GitHub Pages
1. Upload this folder to a new public repository.
2. Go to *Settings → Pages*.
3. Choose branch `main`, folder `/ (root)`.
4. Save, then open your game URL: `https://yourusername.github.io/catch-the-ball/`
